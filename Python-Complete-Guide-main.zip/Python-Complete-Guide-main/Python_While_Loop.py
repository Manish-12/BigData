# Python program to execute for while

num = 1

while num<=10:

	print(num)
	num = num + 1
	# num += 1


# This will be a infinite loop
# while True:
# 	print("Hello")


