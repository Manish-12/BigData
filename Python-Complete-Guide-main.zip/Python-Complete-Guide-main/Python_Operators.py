# Python Arithmetic Operators

a = 10
b = 3

print("Value of a : ", a)
print("Value of b : ", b)
print("Addition of  a + b: ", a+b)
print("Substraction of  a - b: ", a-b)
print("Multiplcation a * b: ", a*b)
print("Noraml Division of  a / b: ", a/b)
print("Integer Division of  a // b: ", a//b)
print("Remainder of  a % b: ", a%b)


# Calculate 2 power of 10

print("Power of a for exponent 2: ", a**2)


# Python Comparison Operators

print("Equal of  a == b: ", a==b)
print("Not Equal of  a != b: ", a!=b)
print("Less Than Equal a <= b: ", a<=b)
print("Greater Than Equal  a >= b: ", a>=b)
print("Less Than  a < b: ", a<b)
print("Greater Than  a > b: ", a>b)


