# Python Program for Tuples

arr_tuple = (2,3,4,7,8)
print("Tuple Otuput : ",arr_tuple)


# Iterate elements without index

for num in arr_tuple:
	print(num)

# Iterate elements with index

for idx in range(0,len(arr_tuple)):
	print("Element at ",idx," index is : ",arr_tuple[idx])