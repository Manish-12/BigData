# Python program for Pass keyword

a = 4

if a<5:
	pass
else:
	print("a is greater than 5")