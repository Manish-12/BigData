# My first Python Program

a = 10
b = 9.2
c = "Shashank"
d = True

print("Value of a : ",a)
print("Value of b : ",b)
print("Value of c : ",c)
print("Value of d : ",d)


# ===== type(a)

print("Data Type of a : ",type(a))
print("Data Type of b : ",type(b))
print("Data Type of c : ",type(c))
print("Data Type of d : ",type(d))


# how to convert one data type to another one or Type Casting


var1 = 123
var2 = "123"

print("Value of var1 : ",var1)
print("Value of var2 : ",var2)

print("Data Type of var1 : ",type(var1))
print("Data Type of var2 : ",type(var2))

var3 = int(var2) + 10
print("Value of var3 : ",var3)
print("Data Type of var3 : ",type(var3))


var4 = 88.54
var5 = int(var4)
print("Value of var5 : ",var5)
print("Data Type of var5 : ",type(var5))

var6 = 90
var7 = float(var6)
print("Value of var7 : ",var7)
print("Data Type of var7 : ",type(var7))



