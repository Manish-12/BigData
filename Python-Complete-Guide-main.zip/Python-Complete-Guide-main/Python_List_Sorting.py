# Program for Sorting a List

arr_list = [8,5,9,3,2,10]

print("List Before Sorting : ",arr_list)

arr_list.sort()

print("List After Sorting in Asc : ",arr_list)

arr_list.sort(reverse=True)

print("List After Sorting in Desc : ",arr_list)