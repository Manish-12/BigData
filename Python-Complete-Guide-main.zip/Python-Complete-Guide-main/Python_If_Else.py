# Python If-Else with logical operators

a = 10
b = 5

if a<b :
	print("True Condition - a is less than b !!")
else:
	print("False Condition - a is not less than b !!")


name = input("Enter your name (Must be a string) : ")
age = input("Enter your age (Must be a integer) : ")
age = int(age)

if (name == "Shashank") and (age == 28):
	print("Shashank's Data Matched !!")
else:
	print("Shashank's Data Mis-Matched !!")