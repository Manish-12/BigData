# Python Input from user

name = input("Enter your name (Must be a string) : ")
age = input("Enter your age (Must be a integer) : ")
age = int(age)
print("Value of name : ",name)
print("Value of age : ",age)
print("Type of name : ",type(name))
print("Type of age : ",type(age))

