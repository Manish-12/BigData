# Python program to execute for loop

# with start and end
for num in range(1,11):
	print(num)


# without start and end
for num in range(10):
	print("Hello")


# print odd numbers
for num in range(1,100,2):
	print(num)